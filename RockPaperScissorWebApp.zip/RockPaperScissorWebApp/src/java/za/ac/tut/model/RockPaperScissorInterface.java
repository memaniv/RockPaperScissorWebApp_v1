package za.ac.tut.model;

/**
 *
 * @author MemaniV
 */
public interface RockPaperScissorInterface {
    public char generateSign();
    public String determineOutcome(char playerSign, char computerSign);
}

