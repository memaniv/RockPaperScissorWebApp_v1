package za.ac.tut.web;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.RockPaperScissorManager;

/**
 *
 * @author MemaniV
 */
public class RockPaperScissorServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { 
        char playerChoice = request.getParameter("choice").charAt(0);
        
        RockPaperScissorManager rpsm = new RockPaperScissorManager();
        char computerChoice = rpsm.generateSign();
        
        String outcome = rpsm.determineOutcome(playerChoice, computerChoice);
        request.setAttribute("playerChoice", playerChoice);
        request.setAttribute("computerChoice", computerChoice);
        request.setAttribute("outcome", outcome);
        
        RequestDispatcher disp = request.getRequestDispatcher("outcome.jsp");
        disp.forward(request, response);
    }
}

